import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { parseArgs } from 'node:util';
import { createHash } from 'node:crypto';
import { readGraphInput, graphDigest } from '../runtime/io-core.mjs';

export const RANK_PACKET_SCHEMA = 'knowme-ranked-evidence-v1';
const order = (a, b) => a.localeCompare(b, 'en');
const date = value => {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value) || !Number.isFinite(Date.parse(value)) || new Date(value).toISOString().slice(0, 10) !== value)
    throw new Error('Dates must be valid YYYY-MM-DD values.');
  return value;
};
let loaded;
export async function loadRankingModule() {
  loaded ??= (async () => {
    const logic = await import('../runtime/ranking-core.mjs');
    const code = JSON.parse(readFileSync(new URL('../runtime/source-provenance.json', import.meta.url), 'utf8'));
    return { logic, code };
  })();
  return loaded;
}

/** Explicit caller-owned preferences; no browser/localStorage/shared-settings access. */
export function rankingProfile(spec, logic, now) {
  if (!spec || typeof spec !== 'object' || Array.isArray(spec) || !spec.topics || typeof spec.topics !== 'object' || Array.isArray(spec.topics))
    throw new Error('Profile must be {"name":"...","topics":{"rag":1,...}}.');
  const entries = Object.entries(spec.topics), known = new Set(logic.topics.map(topic => topic.id));
  if (!entries.length) throw new Error('Select at least one topic.');
  for (const [id, priority] of entries) if (!known.has(id) || ![1, 2, 3, 4].includes(priority))
    throw new Error(`Unknown topic or invalid priority: ${id}; use --list-topics (priorities 1..4).`);
  if (Object.keys(spec).some(key => !['name', 'topics'].includes(key))) throw new Error('Profile accepts only name and topics.');
  if (spec.name !== undefined && (typeof spec.name !== 'string' || !spec.name.trim())) throw new Error('Profile name must be nonempty text.');
  const selection = { topics: entries.map(([id]) => id), terms: entries.flatMap(([id]) => (logic.topicSubtopics[id] ?? []).map(sub => `${id}::${sub.id}`)) };
  const profile = logic.buildTopicProfileSnapshot({ pack: null, selection, priorities: spec.topics, now });
  // Explicit CLI inputs are not old saved subscriptions and must not inherit migration additions.
  const requested = new Set(entries.map(([id]) => id));
  return { ...profile, topics: profile.topics.filter(topic => requested.has(topic.id)),
    packId: 'cli-explicit-profile', packName: spec.name ?? 'CLI research profile' };
}

export async function rankResearchPapers(data, { profile: spec, from, to, limit = 20, excludes = [], now = new Date().toISOString() } = {}) {
  date(from); date(to);
  if (from > to) throw new Error('--from must not be after --to.');
  if (!Number.isSafeInteger(limit) || limit < 1) throw new Error('--limit must be a positive integer.');
  if (!Array.isArray(excludes) || excludes.some(term => typeof term !== 'string' || !term.trim())) throw new Error('Each exclusion must be nonempty literal text.');
  const { logic, code } = await loadRankingModule();
  const profile = rankingProfile(spec, logic, now), priorities = Object.fromEntries(logic.topics.map(topic => [topic.id, spec.topics[topic.id] ?? 4]));
  const selectedTopics = new Set(Object.keys(spec.topics)), excludedTerms = [...new Set(excludes.map(term => term.trim().toLocaleLowerCase('en')))];
  const matchers = logic.topicsWithAllSubtopicTerms(), snapshotDate = now.slice(0, 10);
  const paperFields = ['id', 'version', 'title', 'summary', 'authors', 'published', 'firstSubmittedAt', 'updated', 'categories', 'primaryCategory',
    'affiliations', 'affiliationStatus', 'matchedOrganizations', 'affiliationEvidence', 'affiliationAudit', 'authorAffiliationEvidence', 'authorBylineConflict', 'structuredAuthors', 'metadataVerification',
    'comments', 'journalRef', 'journalReference', 'doi'];
  const records = data.records.map(record => {
    const paper = Object.fromEntries(paperFields.filter(key => record.paper[key] !== undefined).map(key => [key, record.paper[key]]));
    paper.summary ??= ''; paper.affiliations ??= []; paper.matchedOrganizations ??= [];
    return { cachedAt: record.cachedAt ?? null, paper: { ...paper, sourceTopics: logic.matchPaperTopics(paper, matchers) } };
  });
  const candidates = []; let dateEligible = 0, topicEligible = 0, excluded = 0, invalidDate = 0;
  for (const record of records) {
    const paper = record.paper, first = paper.firstSubmittedAt || paper.published;
    if (!Number.isFinite(Date.parse(first))) { invalidDate++; continue; }
    const day = new Date(first).toISOString().slice(0, 10);
    if (day < from || day > to) continue;
    dateEligible++;
    if (!paper.sourceTopics.some(topic => selectedTopics.has(topic.id))) continue;
    topicEligible++;
    const text = `${paper.title}\n${paper.summary}`.toLocaleLowerCase('en');
    if (excludedTerms.some(term => text.includes(term))) { excluded++; continue; }
    candidates.push(record);
  }
  const sourceHasher = createHash('sha256');
  for (const record of records) sourceHasher.update(graphDigest(record)).update('\n');
  const sourceDigest = sourceHasher.digest('hex'), profileDigest = graphDigest(profile);
  const scope = { source: data.scope?.source ?? 'provided-records', from, to, dateField: 'firstSubmittedAt, otherwise published; inclusive UTC dates',
    profile: { name: profile.packName, topics: spec.topics }, exclusions: excludedTerms, exclusionMatch: 'case-insensitive literal substring in title or abstract; candidate filter only',
    limit, sourceRecords: records.length, dateEligible, topicEligible, excluded, eligible: candidates.length, invalidDate,
    selection: 'Recompute live topics; require any explicitly selected topic; score all eligible candidates before output limit.',
    personalContext: 'Complete supplied/current cached bibliography, including candidate papers; current-state ranking, not historical backtest.',
    omittedInputs: ['browser preferences', 'manual author bonuses', 'Scholar profile metrics/evolution', 'external author citation/count metrics'],
    identityAnchors: 'Only explicitly supplied or same-library verified author identity anchors; provider IDs and bound papers, never citation/count scores.', network: false, databaseWrites: false };
  const manifest = { type: 'manifest', schema: RANK_PACKET_SCHEMA, snapshot: { observedAt: now, sourceDigest, profileDigest,
    digestMethod: 'SHA256 of newline-separated SHA256 canonical ranking-input records in source ID order',
    semantics: 'Current metadata and code, not an as-available historical snapshot. Date window filters papers, not evidence timestamps.' },
    scope, code, models: { scoring: logic.SCORING_MODEL_VERSION, topics: logic.TOPIC_MATCHING_VERSION, personal: logic.PERSONAL_RANKING_MODEL, readingPolicy: logic.PAPER_READING_POLICY_VERSION },
    scoreSemantics: 'Scores are raw reading priorities. Batch position uses all eligible personal totals before the output limit. Equal totals share a rank interval and a peer midrank percentile. A batch with only one distinct total has no percentile.' };
  manifest.snapshot.id = graphDigest({ sourceDigest, profileDigest, code: code.bundleSha256, from, to, excludes: excludedTerms, observedAt: now });
  if (!candidates.length) return { manifest: { ...manifest, returned: 0, truncated: false, personalEvidence: { state: 'not-required-empty-selection' } }, papers: [] };
  const graph = logic.buildAuthorGraphAnalysis(records.map(record => record.paper), []), valueIndex = logic.indexAuthorValueProfiles(graph.profiles);
  const prepared = logic.prepareInstitutionDirection(records, snapshotDate, data.authorMetrics ?? []);
  const model = await logic.buildPersonalAuthorModel(records, profile, { identities: prepared.identities, evolution: { profiles: [], papers: [] }, asOf: snapshotDate });
  const institutions = logic.institutionDirectionContext(prepared.snapshot, profile);
  manifest.models.institutionDirection = logic.INSTITUTION_DIRECTION_VERSION;
  const personalProfiles = new Map([...model.authors].map(([key, value]) => [key, value.result]));
  const context = { fingerprint: model.fingerprint, asOf: model.asOf, profileName: profile.packName, institutions, readingProfile: profile, readingClock: { now: Date.parse(now) } };
  const scored = candidates.map(record => {
    const paper = record.paper, base = logic.scorePaper(paper, priorities, valueIndex, undefined, { now: Date.parse(now) }), binding = logic.personalPaperBindings(paper, model);
    const personal = logic.personalizePaperScore(paper, base, binding, personalProfiles, context);
    return { type: 'paper', schema: RANK_PACKET_SCHEMA, snapshotId: manifest.snapshot.id, id: paper.id, version: paper.version ?? null,
      title: paper.title, abstract: paper.summary, authors: paper.authors, categories: paper.categories ?? [],
      url: `https://arxiv.org/abs/${paper.id}${paper.version ? `v${paper.version}` : ''}`, published: paper.firstSubmittedAt || paper.published || null, updated: paper.updated ?? null,
      scores: { base: base.total, personalAuthorAdjustment: personal.authorAdjustment, personalInstitutionAdjustment: personal.institutionAdjustment, technicalEvidenceAdjustment: personal.readingPolicy?.technicalAdjustment ?? 0, typeAgeAdjustment: personal.readingPolicy?.recencyAdjustment ?? 0, total: personal.total,
        components: { topic: base.topicScore, frontierModel: base.frontierModelBonus, institution: base.institutionWeightedScore,
          author: base.authorBonus, networkAuthor: base.networkAuthorBonus, recencyPenalty: base.recencyPenalty, soloAuthorPenalty: base.soloAuthorPenalty, venuePenalty: base.venuePreference.penalty } },
      evidence: { topics: paper.sourceTopics, catalogAuthors: base.influentialAuthors.map(author => ({ name: author.name, authorIndex: author.authorIndex, verified: author.verified, bonus: author.bonus })),
        readingPolicy: personal.readingPolicy, networkAuthors: base.networkAuthors, personalAuthors: personal.authors, personalInstitutions: personal.institutions },
      missing: { abstract: !paper.summary.trim(), affiliationStatus: paper.affiliationStatus ?? 'not-checked', personalAuthorState: binding.state,
        personalInstitutionState: personal.institutions.some(row => row.state === 'ready') ? 'ready' : personal.institutions.some(row => row.scoreState === 'prior-only') ? 'prior-only' : 'insufficient-evidence', scholarMetrics: 'not-loaded' },
      provenance: { observedAt: record.cachedAt ?? null, paperDigest: graphDigest(paper), source: 'cached-metadata' } };
  });
  scored.sort((a, b) => b.scores.total - a.scores.total || order(a.id, b.id));
  const positions = logic.batchScorePositions(scored.map(paper => paper.scores.total));
  const papers = scored.slice(0, limit).map((paper, index) => ({
    ...paper, rank: index + 1, batchPosition: positions.get(paper.scores.total),
    display: { readingIndex: positions.get(paper.scores.total)?.percentile ?? null, raw: paper.scores.total, scale: 'current-complete-result-midrank-percentile', poolSize: scored.length },
  }));
  return { manifest: { ...manifest, returned: papers.length, truncated: scored.length > limit,
    personalEvidence: { counts: model.counts, fingerprint: model.fingerprint, identities: graph.identities.length, networkProfiles: graph.profiles.length, institutionProfiles: institutions.length } }, papers };
}

export async function main(args = process.argv.slice(2)) {
  const { values } = parseArgs({ args, options: { help: { type: 'boolean' }, 'list-topics': { type: 'boolean' }, topics: { type: 'string' }, profile: { type: 'string' },
    from: { type: 'string' }, to: { type: 'string' }, limit: { type: 'string', default: '20' }, exclude: { type: 'string', multiple: true },
    format: { type: 'string', default: 'json' }, input: { type: 'string' }, database: { type: 'string' } } });
  if (values.help) { console.log(`KnowMe ranked evidence CLI — local cache only, no writes or network
node scripts/rank-research-papers.mjs --topics rag:1,reasoning:2 --from 2026-10-01 --to 2026-10-31 --limit 20 --exclude survey --format jsonl
Profile alternative: --profile PROFILE.json where {"name":"My research","topics":{"rag":1,"reasoning":2}}
--input FILE.json or --input - reads {"records":[{"paper":...},...]} instead of the shared read-only SQLite cache.
--list-topics lists valid IDs. Priorities: 1 highest, 4 lowest. All declared topics use their current built-in subtopic terms.
JSON stdout: {manifest,papers}; JSONL stdout: one manifest followed by ranked paper records. Errors go to stderr.
Date filtering is inclusive; output limit is applied after ranking. No browser preferences or model service are read.`); return; }
  if (values['list-topics']) { const { logic } = await loadRankingModule(); console.log(JSON.stringify(logic.topics.map(topic => ({ id: topic.id, name: topic.name })), null, 2)); return; }
  if (Boolean(values.topics) === Boolean(values.profile)) throw new Error('Supply exactly one of --topics or --profile.');
  if (!values.from || !values.to) throw new Error('--from and --to are required.');
  if (!['json', 'jsonl'].includes(values.format)) throw new Error('--format must be json or jsonl.');
  if (!Number.isSafeInteger(Number(values.limit)) || Number(values.limit) < 1) throw new Error('--limit must be a positive integer.');
  if (values.input !== undefined && values.database !== undefined) throw new Error('Choose --input or --database, not both.');
  if (values.input !== undefined && !values.input.trim()) throw new Error('--input must name a file or - for stdin.');
  const pairs = values.topics?.split(',').map(entry => entry.split(':'));
  if (pairs && (pairs.some(pair => pair.length > 2 || !pair[0]) || new Set(pairs.map(pair => pair[0])).size !== pairs.length)) throw new Error('Topic IDs must be unique; use id:priority entries.');
  const spec = values.profile ? JSON.parse(readFileSync(values.profile, 'utf8')) : { topics: Object.fromEntries(pairs.map(([id, priority = '1']) => [id, Number(priority)])) };
  const { logic } = await loadRankingModule(); rankingProfile(spec, logic, new Date().toISOString()); date(values.from); date(values.to);
  if (values.from > values.to) throw new Error('--from must not be after --to.');
  const input = values.input ? JSON.parse(readFileSync(values.input === '-' ? 0 : values.input, 'utf8')) : undefined;
  if (values.input !== undefined && (!input || typeof input !== 'object' || Array.isArray(input) || !Array.isArray(input.records)))
    throw new Error('--input requires an object with a records array.');
  const data = readGraphInput({ database: values.database, input, limit: Number.MAX_SAFE_INTEGER, includeMetadata: false, includeIdentities: false, includeAuthorMetrics: true });
  const packet = await rankResearchPapers(data, { profile: spec, from: values.from, to: values.to, limit: Number(values.limit), excludes: values.exclude ?? [] });
  if (values.format === 'jsonl') { process.stdout.write(JSON.stringify(packet.manifest) + '\n'); for (const paper of packet.papers) process.stdout.write(JSON.stringify(paper) + '\n'); }
  else process.stdout.write(JSON.stringify(packet, null, 2) + '\n');
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) main().catch(error => { console.error(JSON.stringify({ type: 'error', schema: RANK_PACKET_SCHEMA, message: error.message })); process.exitCode = 1; });
