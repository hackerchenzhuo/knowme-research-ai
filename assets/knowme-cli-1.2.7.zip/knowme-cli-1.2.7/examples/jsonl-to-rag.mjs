// Local JSONL format conversion only; no ranking or network access.
import {readFileSync,writeFileSync} from 'node:fs';
const [input='ranked.jsonl',documents='rag-documents.jsonl',ids='selected-ids.json']=process.argv.slice(2);
const rows=readFileSync(input,'utf8').split(/\r?\n/).filter(s=>s.trim()).map(s=>JSON.parse(s));
const papers=rows.filter(r=>r.type==='paper');
const docs=papers.map(p=>({id:p.id,title:p.title,text:p.abstract,source:p.url,snapshotId:p.snapshotId}));
writeFileSync(documents,docs.map(d=>JSON.stringify(d)).join('\n')+(docs.length?'\n':''));
writeFileSync(ids,JSON.stringify(papers.map(p=>p.id),null,2)+'\n');
console.error(JSON.stringify({documents:docs.length,output:documents,ids}));
