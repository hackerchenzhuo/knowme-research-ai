// knowme-cli-input-adapter.mjs
import { DatabaseSync } from "node:sqlite";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { homedir } from "node:os";

// lib/knowledge-graph.mjs
import { createHash } from "node:crypto";

// lib/storage-records.mjs
function isRecord(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}
var sharedStoreKeys = Object.freeze({
  "favorite-papers": "id",
  "affiliation-cache": "id",
  "query-cache": "key",
  "author-metrics": "key",
  "publication-metadata": "key",
  "scholar-paper-metadata": "key",
  "scholar-author-metadata": "key",
  // Role statistics of Google Scholar profiles the owner opened, and the stored papers each profile lists.
  "scholar-author-profiles": "key",
  "openalex-paper-metadata": "key",
  "paper-corpus": "id",
  "author-graph-papers": "id",
  "author-graph-signals": "key",
  "author-graph-nodes": "key",
  "author-identity-entities": "key",
  "author-graph-coverage": "key",
  "feed-coverage": "key",
  "unranked-organizations": "key",
  "organization-display-names": "key",
  "shared-settings": "key"
});
function canonicalStorageJson(value) {
  return JSON.stringify(
    value,
    (_key, item) => isRecord(item) ? Object.fromEntries(
      Object.keys(item).sort((left, right) => left < right ? -1 : left > right ? 1 : 0).map((key) => [key, item[key]])
    ) : item
  );
}
function storageDigest(value) {
  const source = canonicalStorageJson(value);
  let first = 2166136261;
  let second = 5381;
  for (let index = 0; index < source.length; index += 1) {
    const code = source.charCodeAt(index);
    first = Math.imul(first ^ code, 16777619);
    second = Math.imul(second, 33) ^ code;
  }
  return `${source.length}:${(first >>> 0).toString(16)}:${(second >>> 0).toString(16)}`;
}
function paperTopicInput(paper) {
  return [paper.id ?? "", paper.version ?? 0, paper.title, paper.summary];
}
function paperTopicSignature(paper) {
  return storageDigest([paperTopicInput(paper), paper.sourceTopics ?? []]);
}
function validTopicRevision(paper) {
  const evidence = paper.topicMatchEvidence;
  return Number.isSafeInteger(evidence?.revision) && evidence.revision > 0 && evidence.signature === paperTopicSignature(paper) ? evidence.revision : 0;
}
function refreshPaperMetadataBinding(paper) {
  const evidence = paper.metadataVerification;
  if (!evidence) return paper;
  const stale = [];
  if (evidence.version !== paper.version) stale.push("version");
  if (evidence.metadataDatestamp !== paper.metadataDatestamp)
    stale.push("metadataDatestamp");
  if (!stale.length) return paper;
  if (evidence.status === "needs-review" && !evidence.verifiedFields?.length && !paper.structuredAuthors && stale.every((field) => evidence.conflicts?.includes(field)))
    return paper;
  return {
    ...paper,
    structuredAuthors: void 0,
    metadataVerification: {
      ...evidence,
      status: "needs-review",
      verifiedFields: [],
      conflicts: [.../* @__PURE__ */ new Set([...evidence.conflicts ?? [], ...stale])]
    }
  };
}
function affiliationStatusScore(status) {
  return status === "verified-document" ? 4 : status === "verified-html" ? 3 : status === "verified-metadata" ? 2 : status === "inferred-author-network" ? 1 : 0;
}
function paperInformationScore(value) {
  const paper = value;
  const affiliations = Array.isArray(paper.affiliations) ? paper.affiliations.filter((item) => typeof item === "string").length : 0;
  const matchedOrganizations = Array.isArray(paper.matchedOrganizations) ? paper.matchedOrganizations.length : 0;
  const sourceTopics = Array.isArray(paper.sourceTopics) ? paper.sourceTopics.filter(
    (topic) => isRecord(topic) && topic.id !== "arxiv-loose-match"
  ).length : 0;
  return affiliationStatusScore(paper.affiliationStatus) * 1e4 + affiliations * 100 + matchedOrganizations * 10 + sourceTopics;
}
function paperAffiliationEvidenceScore(value) {
  const paper = value;
  const affiliations = Array.isArray(paper.affiliations) ? paper.affiliations.filter((item) => typeof item === "string").length : 0;
  return affiliationStatusScore(paper.affiliationStatus) * 1e4 + affiliations;
}
function paperArrayScore(value, key) {
  const items = value[key];
  if (!Array.isArray(items)) return 0;
  if (key === "sourceTopics")
    return items.reduce(
      (score, item) => score + (isRecord(item) && item.id !== "arxiv-loose-match" ? 100 : 1) + (isRecord(item) && Array.isArray(item.matchedTerms) ? item.matchedTerms.length : 0),
      0
    );
  return items.length;
}
function laterPaper(existing, incoming) {
  const existingRecord = existing;
  const incomingRecord = incoming;
  const existingVersion = Number(existingRecord.version);
  const incomingVersion = Number(incomingRecord.version);
  if (Number.isFinite(existingVersion) && Number.isFinite(incomingVersion) && incomingVersion !== existingVersion)
    return incomingVersion > existingVersion ? incoming : existing;
  const dateEvidence = (record) => record.dateSource === "announcement-rss" ? 0 : record.dateSource === "arxiv-search" ? 1 : 2;
  if (dateEvidence(existingRecord) !== dateEvidence(incomingRecord))
    return dateEvidence(incomingRecord) > dateEvidence(existingRecord) ? incoming : existing;
  const existingUpdatedValue = existing.updated;
  const incomingUpdatedValue = incoming.updated;
  const existingUpdated = Date.parse(
    typeof existingUpdatedValue === "string" ? existingUpdatedValue : ""
  );
  const incomingUpdated = Date.parse(
    typeof incomingUpdatedValue === "string" ? incomingUpdatedValue : ""
  );
  if (Number.isFinite(existingUpdated) && Number.isFinite(incomingUpdated) && incomingUpdated !== existingUpdated)
    return incomingUpdated > existingUpdated ? incoming : existing;
  return paperInformationScore(incoming) > paperInformationScore(existing) ? incoming : existing;
}
function isPaperBoundAuthorBylineConflict(paper, evidence = paper.authorBylineConflict) {
  return Boolean(
    evidence?.source === "manual-document" && evidence.sourceVersionConfirmed === true && evidence.paperId === paper.id && Number(evidence.version) > 0 && Number(evidence.version) === Number(paper.version) && Number.isFinite(Date.parse(evidence.paperUpdated)) && Date.parse(evidence.paperUpdated) === Date.parse(paper.updated) && Number.isFinite(Date.parse(evidence.checkedAt)) && /^[a-f0-9]{64}$/.test(evidence.sourceDigest ?? "") && typeof evidence.sourcePath === "string" && evidence.sourcePath.length > 0 && Array.isArray(evidence.authors) && evidence.authors.length > 0 && canonicalStorageJson(evidence.authors) === canonicalStorageJson(paper.authors) && Array.isArray(evidence.observedAuthors) && evidence.observedAuthors.length > 0 && evidence.observedAuthors.every(
      (name) => typeof name === "string" && name.trim()
    ) && canonicalStorageJson(evidence.authors) !== canonicalStorageJson(evidence.observedAuthors)
  );
}
function isPaperBoundAuthorAffiliationEvidence(paper, evidence) {
  const normalized = (name) => typeof name === "string" ? name.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]+/g, " ").trim() : "";
  return Boolean(
    evidence && evidence.paperId === paper.id && Number(evidence.version) === Number(paper.version) && Number.isFinite(Date.parse(evidence.paperUpdated)) && Date.parse(evidence.paperUpdated) === Date.parse(paper.updated) && /^[a-f0-9]{64}$/.test(evidence.sourceDigest ?? "") && [
      "arxiv-html",
      "arxiv-oai",
      "manual-document",
      "openalex-work",
      "crossref-publication"
    ].includes(evidence.source) && Array.isArray(evidence.authors) && evidence.authors.length > 0 && evidence.authors.length === paper.authors?.length && evidence.authors.every(
      (author, index) => normalized(author.name) && normalized(author.name) === normalized(paper.authors[index]) && Array.isArray(author.affiliations) && author.affiliations.every(
        (affiliation) => typeof affiliation === "string" && affiliation.trim()
      )
    )
  );
}
function preferRicherPaper(existing, incoming) {
  if (!existing) return incoming;
  if (JSON.stringify(existing) === JSON.stringify(incoming)) return existing;
  const base = laterPaper(existing, incoming);
  const other = base === incoming ? existing : incoming;
  const sameVersion = Number(base.version) > 0 && Number(base.version) === Number(other.version);
  const sameUpdate = Number.isFinite(Date.parse(base.updated)) && Date.parse(base.updated) === Date.parse(other.updated);
  const differentVersions = Number(base.version) > 0 && Number(other.version) > 0 && !sameVersion;
  const mayReuseAffiliation = !differentVersions && (sameVersion || sameUpdate || other.affiliationEvidence?.version === Number(base.version) && Date.parse(other.affiliationEvidence?.paperUpdated) === Date.parse(base.updated));
  const affiliationEvidence = mayReuseAffiliation && paperAffiliationEvidenceScore(other) > paperAffiliationEvidenceScore(base) ? other : base;
  const sameAffiliationEvidence = base.affiliationStatus === other.affiliationStatus && canonicalStorageJson(base.affiliations ?? []) === canonicalStorageJson(other.affiliations ?? []);
  const organizationEvidence = sameAffiliationEvidence ? paperArrayScore(other, "matchedOrganizations") > paperArrayScore(base, "matchedOrganizations") ? other : base : affiliationEvidence;
  const sameTopicInput = canonicalStorageJson(paperTopicInput(base)) === canonicalStorageJson(paperTopicInput(other));
  const baseTopicRevision = validTopicRevision(base);
  const otherTopicRevision = validTopicRevision(other);
  const topicEvidence = !sameTopicInput ? base : baseTopicRevision !== otherTopicRevision ? otherTopicRevision > baseTopicRevision ? other : base : baseTopicRevision > 0 ? base : paperArrayScore(other, "sourceTopics") > paperArrayScore(base, "sourceTopics") ? other : base;
  const baseRecord = base;
  const affiliationRecord = affiliationEvidence;
  const organizationRecord = organizationEvidence;
  const topicRecord = topicEvidence;
  const authorAffiliationEvidence = [base, other].map((paper) => paper.authorAffiliationEvidence).filter((evidence) => isPaperBoundAuthorAffiliationEvidence(base, evidence)).sort(
    (left, right) => Number(right.sourceVersionConfirmed === true) - Number(left.sourceVersionConfirmed === true) || right.authors.filter((author) => author.affiliations.length > 0).length - left.authors.filter((author) => author.affiliations.length > 0).length
  )[0];
  const authorBylineConflict = [base, other].map((paper) => paper.authorBylineConflict).filter(
    (evidence) => evidence && isPaperBoundAuthorBylineConflict(base, evidence)
  ).sort(
    (left, right) => Date.parse(right.checkedAt) - Date.parse(left.checkedAt)
  )[0];
  let merged = {
    ...other,
    ...baseRecord,
    affiliations: affiliationRecord.affiliations,
    affiliationStatus: affiliationRecord.affiliationStatus,
    affiliationEvidence: affiliationRecord.affiliationEvidence,
    authorAffiliationEvidence,
    authorBylineConflict,
    matchedOrganizations: organizationRecord.matchedOrganizations,
    sourceTopics: topicRecord.sourceTopics,
    topicMatchEvidence: validTopicRevision(topicRecord) ? topicRecord.topicMatchEvidence : void 0
  };
  const validDate = (value) => typeof value === "string" && Number.isFinite(Date.parse(value));
  const firstSubmission = (record) => {
    if (validDate(record.firstSubmittedAt)) return record.firstSubmittedAt;
    if (record.dateSource === "announcement-rss") return void 0;
    if (Number(record.version) > 1 && (record.dateSource === "arxiv-search" || !record.dateSource && record.published === record.updated))
      return void 0;
    return validDate(record.published) ? record.published : void 0;
  };
  const submittedAt = firstSubmission(baseRecord) ?? firstSubmission(other);
  if (submittedAt && !firstSubmission(baseRecord)) {
    merged.firstSubmittedAt = submittedAt;
    merged.published = submittedAt;
  }
  const announcements = [baseRecord, other].map(
    (record) => record.announcedAt ?? (record.dateSource === "announcement-rss" ? record.updated : void 0)
  ).filter(validDate).sort((left, right) => Date.parse(right) - Date.parse(left));
  if (announcements.length) merged.announcedAt = announcements[0];
  if (Array.isArray(merged.affiliations) && merged.affiliations.length > 0 && "unknownAffiliationFallback" in merged)
    merged.unknownAffiliationFallback = false;
  merged = refreshPaperMetadataBinding(merged);
  if (JSON.stringify(existing) === JSON.stringify(merged)) return existing;
  if (JSON.stringify(incoming) === JSON.stringify(merged)) return incoming;
  return merged;
}

// lib/knowledge-graph.mjs
var graphDigest = (value) => createHash("sha256").update(typeof value === "string" ? value : canonicalStorageJson(value)).digest("hex");
var order = (a, b) => a.localeCompare(b, "en");
var KG_PREDICATES = Object.freeze({
  authored_by: { domain: "paper", range: "author", directed: true, meaning: "Paper-bound byline occurrence; identity confidence is explicit." },
  coauthor: { domain: "author", range: "author", directed: false, meaning: "Shared authorship on an identified paper; not mentorship or citation." },
  paper_shares_author: { domain: "paper", range: "paper", directed: false, meaning: "Papers linked through the same resolved author; not citation." },
  cites: { domain: "paper", range: "paper", directed: true, meaning: "Outgoing referenced_works asserted by a uniquely bound OpenAlex work index; not source-version verification." },
  has_category: { domain: "paper", range: "category", directed: true, meaning: "Source arXiv subject classification." },
  affiliated_with: { domain: "paper", range: "institution", directed: true, meaning: "Directly verified paper-level institution evidence; not an author current affiliation." }
});
function canonicalGraphRecords(records) {
  const byId = /* @__PURE__ */ new Map();
  for (const record of records) {
    const paper = record?.paper;
    if (!paper?.id || !paper.title || !Array.isArray(paper.authors)) continue;
    const previous = byId.get(paper.id);
    if (!previous) byId.set(paper.id, record);
    else byId.set(paper.id, {
      ...previous,
      ...record,
      paper: preferRicherPaper(previous.paper, paper),
      cachedAt: [previous.cachedAt, record.cachedAt].filter(Boolean).sort(order).at(-1)
    });
  }
  return [...byId.values()].sort((a, b) => order(a.paper.id, b.paper.id));
}

// knowme-cli-input-adapter.mjs
var defaultDatabase = join(homedir(), "Library/Application Support/PaperRadar/paper-radar.sqlite");
var json = (path) => JSON.parse(readFileSync(path, "utf8"));
function readGraphInput({ database = defaultDatabase, input, ids, category, query, limit = 1e3, includeMetadata = true, includeIdentities = true, includeAuthorMetrics = false } = {}) {
  if (!Number.isSafeInteger(limit) || limit < 1) throw new Error("--limit must be a positive integer.");
  if (ids && (!Array.isArray(ids) || ids.some((id) => typeof id !== "string"))) throw new Error("--ids must contain a JSON array of arXiv IDs.");
  const wanted = ids ? new Set(ids) : null;
  const match = (paper) => paper && (!wanted || wanted.has(paper.id)) && (!category || paper.categories?.includes(category)) && (!query || `${paper.title ?? ""}
${paper.summary ?? ""}`.toLocaleLowerCase("en").includes(query.toLocaleLowerCase("en")));
  const scope = {
    category: category ?? null,
    query: query ?? null,
    explicitIds: ids ?? null,
    limit,
    selection: "ID order after exact category and literal title/abstract query filtering; bounded local snapshot, not global subfield recall."
  };
  if (input) {
    const data = typeof input === "string" ? json(input) : input;
    const eligible = canonicalGraphRecords(data.records ?? []).filter((row) => match(row.paper));
    const records = eligible.slice(0, limit), selected = new Set(records.map((row) => row.paper.id));
    return {
      records,
      identities: includeIdentities ? data.identities ?? [] : [],
      metadataRecords: includeMetadata ? (data.metadataRecords ?? []).filter((row) => selected.has(row.key)) : [],
      ...includeAuthorMetrics ? { authorMetrics: data.authorMetrics ?? [] } : {},
      scope: { ...scope, eligiblePapers: eligible.length, selectionTruncated: eligible.length > limit, source: "input-json" }
    };
  }
  const db = new DatabaseSync(database, { readOnly: true });
  try {
    db.exec("BEGIN");
    const read = db.prepare("SELECT value FROM records WHERE store=? AND key=?");
    const records = [];
    const keys = wanted ? [...wanted].sort((a, b) => a.localeCompare(b, "en")) : db.prepare("SELECT key FROM records WHERE store IN ('paper-corpus','author-graph-papers') GROUP BY key ORDER BY key").all().map((row) => row.key);
    let eligiblePapers = 0;
    for (const id of keys) {
      const candidates = ["paper-corpus", "author-graph-papers"].flatMap((store) => {
        const row = read.get(store, id);
        return row ? [JSON.parse(row.value)] : [];
      });
      const record = canonicalGraphRecords(candidates)[0];
      if (!match(record?.paper)) continue;
      eligiblePapers++;
      if (records.length < limit) records.push(record);
    }
    const selected = new Set(records.map((row) => row.paper.id));
    const identities = [];
    if (includeIdentities) for (const row of db.prepare("SELECT value FROM records WHERE store='author-identity-entities' ORDER BY key").iterate()) {
      const value = JSON.parse(row.value);
      if (value.paperIds?.some((id) => selected.has(id))) identities.push(value);
    }
    const metadataRecords = includeMetadata ? records.flatMap((row) => {
      const v = read.get("openalex-paper-metadata", row.paper.id);
      return v ? [JSON.parse(v.value)] : [];
    }) : [];
    const authorMetrics = includeAuthorMetrics ? db.prepare("SELECT value FROM records WHERE store='author-metrics' ORDER BY key").all().map((row) => JSON.parse(row.value)) : [];
    db.exec("COMMIT");
    return { records, identities, metadataRecords, ...includeAuthorMetrics ? { authorMetrics } : {}, scope: { ...scope, source: "read-only-shared-sqlite", eligiblePapers, selectionTruncated: eligiblePapers > limit } };
  } finally {
    db.close();
  }
}
export {
  graphDigest,
  readGraphInput
};
